package com.bokchi.mysolelife.contentsList

data class BookmarkModel (
    val bookmarkIsTrue : Boolean? = null
)