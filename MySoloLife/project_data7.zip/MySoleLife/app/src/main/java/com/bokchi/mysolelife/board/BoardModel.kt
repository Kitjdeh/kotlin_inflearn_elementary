package com.bokchi.mysolelife.board

data class BoardModel (
    val title : String = "",
    val content : String = "",
    val uid : String = "",
    val time : String = ""
)